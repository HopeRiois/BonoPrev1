package com.example.Bonus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BonusApplicationTests {

	@Test
	void contextLoads() {
	}

}
